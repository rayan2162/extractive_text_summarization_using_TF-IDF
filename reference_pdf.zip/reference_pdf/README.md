# These PDFs and materials may be subject to copyright.

# I do not own these materials nor do I have permission to distribute them. 

# They are provided solely for educational purposes, to facilitate access to reference papers.

# Please cite these sources appropriately if you use them

## Thank you
